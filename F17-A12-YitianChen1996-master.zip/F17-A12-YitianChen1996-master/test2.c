#include <stdio.h>

int main() {
	printf("1 2");
	return 0;
}
